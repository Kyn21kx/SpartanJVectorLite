public class Vector2 implements Vector {

	private double x;
	private double y;

	public Vector2(double x, double y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public double getX() {
		return this.x;
	}

	@Override
	public double getY() {
		return this.y;
	}

	@Override
	public double calculateTheta() {
		//Soh Cah Toa
		//x = ad, y = op
		return Math.tan((y / x));
	}

	@Override
	public double calculateMagnitude() {
		double powerX = Math.pow(x, 2);
		double powerY = Math.pow(y, 2);
		return Math.sqrt(powerX + powerY);
	}
}
