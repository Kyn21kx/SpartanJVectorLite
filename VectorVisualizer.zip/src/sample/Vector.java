public interface Vector {

	double getX();

	double getY();

	double calculateTheta();

	double calculateMagnitude();

}
