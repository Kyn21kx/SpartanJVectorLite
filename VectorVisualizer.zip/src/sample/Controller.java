package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class Controller extends VBox {

	public final int CANVAS_WIDTH = 240;
	public final int CANVAS_HEIGHT = 360;

	private CheckBox editButton;
	private Canvas canvas;

	public Controller() {
		canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
		this.getChildren().add(canvas);
	}
	
	public void draw() {
		GraphicsContext g = this.canvas.getGraphicsContext2D();
		g.setFill(Color.LIGHTCYAN);
		g.fillRect(Main.WIDTH, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
	}

}
