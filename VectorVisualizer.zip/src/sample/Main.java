package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.net.URL;

public class Main extends Application {

    public static final int WIDTH = 720;
    public static final int HEIGHT = 480;

    @Override
    public void start(Stage primaryStage) throws Exception{
        Controller controller = new Controller();
        primaryStage.setTitle("Vector visualizer");
        primaryStage.setScene(new Scene(controller, WIDTH, HEIGHT));
        primaryStage.show();
        controller.draw();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
